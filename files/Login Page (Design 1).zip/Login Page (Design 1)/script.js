document.addEventListener("DOMContentLoaded", () => {
  // DOM Elements
  const container = document.getElementById("container");
  const signUpBtn = document.getElementById("signUpBtn");
  const signInBtn = document.getElementById("signInBtn");
  
  const loginForm = document.getElementById("loginForm");
  const signUpForm = document.getElementById("signUpForm");
  const toast = document.getElementById("toast");

  /* ==========================================
     1. PANEL SWITCHING ANIMATION
     ========================================== */
  signUpBtn.addEventListener("click", () => {
    container.classList.add("right-panel-active");
  });

  signInBtn.addEventListener("click", () => {
    container.classList.remove("right-panel-active");
  });

  /* ==========================================
     2. PASSWORD VISIBILITY TOGGLE
     ========================================== */
  const togglePasswordIcons = document.querySelectorAll(".toggle-password");

  togglePasswordIcons.forEach((icon) => {
    icon.addEventListener("click", function () {
      const input = this.previousElementSibling;
      if (input.type === "password") {
        input.type = "text";
        this.classList.remove("fa-eye");
        this.classList.add("fa-eye-slash");
      } else {
        input.type = "password";
        this.classList.remove("fa-eye-slash");
        this.classList.add("fa-eye");
      }
    });
  });

  /* ==========================================
     3. TOAST NOTIFICATION SYSTEM
     ========================================== */
  function showToast(message, type = "success") {
    const toastIcon = toast.querySelector(".toast-icon");
    const toastMsg = toast.querySelector(".toast-msg");

    toast.className = "toast"; // Reset classes
    toast.classList.add(type);

    if (type === "success") {
      toastIcon.className = "toast-icon fa-solid fa-circle-check";
    } else {
      toastIcon.className = "toast-icon fa-solid fa-circle-xmark";
    }

    toastMsg.textContent = message;
    toast.classList.add("show");

    setTimeout(() => {
      toast.classList.remove("show");
    }, 3500);
  }

  /* ==========================================
     4. FORM VALIDATION & SUBMISSION
     ========================================== */
  
  // LOGIN SUBMISSION
  loginForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const email = document.getElementById("loginEmail").value.trim();
    const password = document.getElementById("loginPassword").value.trim();
    const submitBtn = loginForm.querySelector("button[type='submit']");

    // Simple Validation
    if (!validateEmail(email)) {
      triggerError(loginForm, "Please enter a valid email address");
      return;
    }

    if (password.length < 6) {
      triggerError(loginForm, "Password must be at least 6 characters");
      return;
    }

    // Simulate API Request Loading
    submitBtn.classList.add("loading");
    
    setTimeout(() => {
      submitBtn.classList.remove("loading");
      showToast("Welcome back! Login successful.", "success");
      loginForm.reset();
    }, 1800);
  });

  // SIGN UP SUBMISSION
  signUpForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const name = document.getElementById("signUpName").value.trim();
    const email = document.getElementById("signUpEmail").value.trim();
    const password = document.getElementById("signUpPassword").value;
    const confirmPassword = document.getElementById("signUpConfirmPassword").value;
    const terms = document.getElementById("termsCheck").checked;
    const submitBtn = signUpForm.querySelector("button[type='submit']");

    if (name === "") {
      triggerError(signUpForm, "Please enter your full name");
      return;
    }

    if (!validateEmail(email)) {
      triggerError(signUpForm, "Please enter a valid email address");
      return;
    }

    if (password.length < 6) {
      triggerError(signUpForm, "Password must be at least 6 characters");
      return;
    }

    if (password !== confirmPassword) {
      triggerError(signUpForm, "Passwords do not match");
      return;
    }

    if (!terms) {
      triggerError(signUpForm, "You must agree to the Terms & Conditions");
      return;
    }

    // Simulate API Request Loading
    submitBtn.classList.add("loading");

    setTimeout(() => {
      submitBtn.classList.remove("loading");
      showToast("Account created successfully!", "success");
      signUpForm.reset();
      
      // Auto switch to login form after signup
      setTimeout(() => {
        container.classList.remove("right-panel-active");
      }, 1000);
    }, 1800);
  });

  /* Helper Functions */
  function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  }

  function triggerError(formElement, message) {
    showToast(message, "error");
    formElement.classList.add("shake");
    setTimeout(() => {
      formElement.classList.remove("shake");
    }, 400);
  }
});