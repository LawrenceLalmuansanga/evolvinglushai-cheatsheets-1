document.addEventListener("DOMContentLoaded", () => {
  // Elements
  const loginTabBtn = document.getElementById("loginTabBtn");
  const signUpTabBtn = document.getElementById("signUpTabBtn");
  const pillGlider = document.getElementById("pillGlider");
  
  const loginForm = document.getElementById("loginForm");
  const signUpForm = document.getElementById("signUpForm");
  
  const toast = document.getElementById("toast");
  const toastIcon = document.getElementById("toastIcon");
  const toastMessage = document.getElementById("toastMessage");

  const signUpPasswordInput = document.getElementById("signUpPassword");
  const strengthBar = document.getElementById("strengthBar");
  const strengthText = document.getElementById("strengthText");

  /* ==========================================
     1. SEGMENTED TAB SWITCHING LOGIC
     ========================================== */
  function switchToTab(tab) {
    if (tab === "signup") {
      pillGlider.style.transform = "translateX(100%)";
      loginTabBtn.classList.remove("active");
      signUpTabBtn.classList.add("active");

      loginForm.classList.remove("active");
      signUpForm.classList.add("active");
    } else {
      pillGlider.style.transform = "translateX(0%)";
      signUpTabBtn.classList.remove("active");
      loginTabBtn.classList.add("active");

      signUpForm.classList.remove("active");
      loginForm.classList.add("active");
    }
  }

  loginTabBtn.addEventListener("click", () => switchToTab("login"));
  signUpTabBtn.addEventListener("click", () => switchToTab("signup"));

  /* ==========================================
     2. PASSWORD VISIBILITY TOGGLE
     ========================================== */
  const togglePassIcons = document.querySelectorAll(".toggle-pass");
  togglePassIcons.forEach((icon) => {
    icon.addEventListener("click", function () {
      const input = this.previousElementSibling;
      if (input.type === "password") {
        input.type = "text";
        this.classList.replace("fa-eye", "fa-eye-slash");
      } else {
        input.type = "password";
        this.classList.replace("fa-eye-slash", "fa-eye");
      }
    });
  });

  /* ==========================================
     3. REAL-TIME PASSWORD STRENGTH METER
     ========================================== */
  signUpPasswordInput.addEventListener("input", function () {
    const val = this.value;
    let score = 0;

    if (val.length >= 6) score += 25;
    if (val.match(/[A-Z]/)) score += 25;
    if (val.match(/[0-9]/)) score += 25;
    if (val.match(/[^A-Za-z0-9]/)) score += 25;

    strengthBar.style.width = score + "%";

    if (score === 0) {
      strengthBar.style.backgroundColor = "transparent";
      strengthText.textContent = "Enter a password";
    } else if (score <= 25) {
      strengthBar.style.backgroundColor = "var(--error)";
      strengthText.textContent = "Weak password";
    } else if (score <= 50) {
      strengthBar.style.backgroundColor = "var(--warning)";
      strengthText.textContent = "Moderate strength";
    } else if (score <= 75) {
      strengthBar.style.backgroundColor = "var(--accent-cyan)";
      strengthText.textContent = "Good strength";
    } else {
      strengthBar.style.backgroundColor = "var(--success)";
      strengthText.textContent = "Strong password";
    }
  });

  /* ==========================================
     4. TOAST NOTIFICATIONS
     ========================================== */
  function showToast(msg, type = "success") {
    toastMessage.textContent = msg;
    toast.className = `toast ${type} show`;

    if (type === "success") {
      toastIcon.className = "fa-solid fa-circle-check";
    } else {
      toastIcon.className = "fa-solid fa-circle-xmark";
    }

    setTimeout(() => {
      toast.classList.remove("show");
    }, 3500);
  }

  /* ==========================================
     5. FORM SUBMISSIONS & VALIDATIONS
     ========================================== */
  
  // Login Form
  loginForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const email = document.getElementById("loginEmail").value.trim();
    const pass = document.getElementById("loginPassword").value.trim();
    const submitBtn = loginForm.querySelector(".submit-btn");

    if (!email || !email.includes("@")) {
      triggerError(loginForm, "Please enter a valid email address");
      return;
    }
    if (pass.length < 6) {
      triggerError(loginForm, "Password must be at least 6 characters");
      return;
    }

    // Simulate API loading
    submitBtn.classList.add("loading");
    setTimeout(() => {
      submitBtn.classList.remove("loading");
      showToast("Signed in successfully!", "success");
      loginForm.reset();
    }, 1500);
  });

  // Sign Up Form
  signUpForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const name = document.getElementById("signUpName").value.trim();
    const email = document.getElementById("signUpEmail").value.trim();
    const pass = document.getElementById("signUpPassword").value;
    const submitBtn = signUpForm.querySelector(".submit-btn");

    if (!name) {
      triggerError(signUpForm, "Full Name is required");
      return;
    }
    if (!email || !email.includes("@")) {
      triggerError(signUpForm, "Please enter a valid email");
      return;
    }
    if (pass.length < 6) {
      triggerError(signUpForm, "Password must be at least 6 characters");
      return;
    }

    // Simulate API loading
    submitBtn.classList.add("loading");
    setTimeout(() => {
      submitBtn.classList.remove("loading");
      showToast("Account created successfully!", "success");
      signUpForm.reset();
      
      // Auto switch back to login tab after brief pause
      setTimeout(() => switchToTab("login"), 1000);
    }, 1500);
  });

  function triggerError(form, message) {
    showToast(message, "error");
    form.classList.add("shake");
    setTimeout(() => form.classList.remove("shake"), 400);
  }
});