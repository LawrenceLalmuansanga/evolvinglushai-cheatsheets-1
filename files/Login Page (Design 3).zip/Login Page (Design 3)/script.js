document.addEventListener("DOMContentLoaded", () => {
  // Elements
  const cardWrapper = document.getElementById("cardWrapper");
  const flipToSignUp = document.getElementById("flipToSignUp");
  const flipToLogin = document.getElementById("flipToLogin");

  const loginForm = document.getElementById("loginForm");
  const signUpForm = document.getElementById("signUpForm");

  const toast = document.getElementById("toast");
  const toastIcon = document.getElementById("toastIcon");
  const toastMsg = document.getElementById("toastMsg");

  /* ==========================================
     1. 3D FLIP CARD TOGGLE
     ========================================== */
  flipToSignUp.addEventListener("click", () => {
    cardWrapper.classList.add("is-flipped");
  });

  flipToLogin.addEventListener("click", () => {
    cardWrapper.classList.remove("is-flipped");
  });

  /* ==========================================
     2. PASSWORD VISIBILITY TOGGLE
     ========================================== */
  const togglePassIcons = document.querySelectorAll(".toggle-pass");

  togglePassIcons.forEach((icon) => {
    icon.addEventListener("click", function () {
      const input = this.previousElementSibling;
      if (input.type === "password") {
        input.type = "text";
        this.classList.replace("fa-eye", "fa-eye-slash");
      } else {
        input.type = "password";
        this.classList.replace("fa-eye-slash", "fa-eye");
      }
    });
  });

  /* ==========================================
     3. TOAST SYSTEM
     ========================================== */
  function showToast(message, type = "success") {
    toastMsg.textContent = message;
    toast.className = `toast ${type} show`;

    if (type === "success") {
      toastIcon.className = "fa-solid fa-circle-check";
    } else {
      toastIcon.className = "fa-solid fa-circle-xmark";
    }

    setTimeout(() => {
      toast.classList.remove("show");
    }, 3500);
  }

  /* ==========================================
     4. FORM VALIDATION & SUBMISSION
     ========================================== */

  // Login Form
  loginForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const email = document.getElementById("loginEmail").value.trim();
    const pass = document.getElementById("loginPassword").value.trim();
    const submitBtn = loginForm.querySelector(".cta-btn");

    if (!email || !email.includes("@")) {
      triggerError(loginForm, "Please enter a valid email address");
      return;
    }

    if (pass.length < 6) {
      triggerError(loginForm, "Password must be at least 6 characters");
      return;
    }

    submitBtn.classList.add("loading");

    setTimeout(() => {
      submitBtn.classList.remove("loading");
      showToast("Signed in successfully!", "success");
      loginForm.reset();
    }, 1500);
  });

  // Sign Up Form
  signUpForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const name = document.getElementById("signUpName").value.trim();
    const email = document.getElementById("signUpEmail").value.trim();
    const pass = document.getElementById("signUpPassword").value;
    const terms = document.getElementById("termsCheck").checked;
    const submitBtn = signUpForm.querySelector(".cta-btn");

    if (!name) {
      triggerError(signUpForm, "Full Name is required");
      return;
    }

    if (!email || !email.includes("@")) {
      triggerError(signUpForm, "Please enter a valid email address");
      return;
    }

    if (pass.length < 6) {
      triggerError(signUpForm, "Password must be at least 6 characters");
      return;
    }

    if (!terms) {
      triggerError(signUpForm, "You must agree to the Terms of Service");
      return;
    }

    submitBtn.classList.add("loading");

    setTimeout(() => {
      submitBtn.classList.remove("loading");
      showToast("Account created successfully!", "success");
      signUpForm.reset();

      // Automatically flip back to login card
      setTimeout(() => {
        cardWrapper.classList.remove("is-flipped");
      }, 1000);
    }, 1500);
  });

  function triggerError(formElement, message) {
    showToast(message, "error");
    formElement.classList.add("shake");
    setTimeout(() => {
      formElement.classList.remove("shake");
    }, 400);
  }
});