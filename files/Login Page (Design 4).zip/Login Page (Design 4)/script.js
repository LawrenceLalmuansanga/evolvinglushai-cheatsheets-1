document.addEventListener("DOMContentLoaded", () => {
  // Elements
  const appWrapper = document.getElementById("appWrapper");
  const btnToSignUp = document.getElementById("btnToSignUp");
  const btnToLogin = document.getElementById("btnToLogin");

  const loginShowcase = document.querySelector(".login-showcase");
  const signupShowcase = document.querySelector(".signup-showcase");

  const loginContainer = document.getElementById("loginContainer");
  const signupContainer = document.getElementById("signupContainer");

  const loginForm = document.getElementById("loginForm");
  const signUpForm = document.getElementById("signUpForm");

  const toast = document.getElementById("toast");
  const toastIcon = document.getElementById("toastIcon");
  const toastMsg = document.getElementById("toastMsg");

  /* ==========================================
     1. FULL-SCREEN CURTAIN SLIDE TOGGLE
     ========================================== */
  btnToSignUp.addEventListener("click", () => {
    appWrapper.classList.add("sign-up-mode");

    // Transition showcase text content
    loginShowcase.classList.remove("active");
    signupShowcase.classList.add("active");

    // Transition form content
    loginContainer.classList.remove("active");
    signupContainer.classList.add("active");
  });

  btnToLogin.addEventListener("click", () => {
    appWrapper.classList.remove("sign-up-mode");

    // Transition showcase text content
    signupShowcase.classList.remove("active");
    loginShowcase.classList.add("active");

    // Transition form content
    signupContainer.classList.remove("active");
    loginContainer.classList.add("active");
  });

  /* ==========================================
     2. PASSWORD VISIBILITY TOGGLE
     ========================================== */
  const togglePassIcons = document.querySelectorAll(".toggle-password");

  togglePassIcons.forEach((icon) => {
    icon.addEventListener("click", function () {
      const input = this.previousElementSibling;
      if (input.type === "password") {
        input.type = "text";
        this.classList.replace("fa-eye", "fa-eye-slash");
      } else {
        input.type = "password";
        this.classList.replace("fa-eye-slash", "fa-eye");
      }
    });
  });

  /* ==========================================
     3. TOAST NOTIFICATIONS
     ========================================== */
  function showToast(message, type = "success") {
    toastMsg.textContent = message;
    toast.className = `toast ${type} show`;

    if (type === "success") {
      toastIcon.className = "fa-solid fa-circle-check";
    } else {
      toastIcon.className = "fa-solid fa-circle-xmark";
    }

    setTimeout(() => {
      toast.classList.remove("show");
    }, 3500);
  }

  /* ==========================================
     4. FORM SUBMISSIONS & VALIDATION
     ========================================== */

  // Login Form Submission
  loginForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const email = document.getElementById("loginEmail").value.trim();
    const pass = document.getElementById("loginPassword").value.trim();
    const submitBtn = loginForm.querySelector(".action-btn");

    if (!email || !email.includes("@")) {
      triggerError(loginForm, "Please enter a valid work email address");
      return;
    }

    if (pass.length < 6) {
      triggerError(loginForm, "Password must be at least 6 characters");
      return;
    }

    submitBtn.classList.add("loading");

    setTimeout(() => {
      submitBtn.classList.remove("loading");
      showToast("Welcome back! Redirecting to workspace...", "success");
      loginForm.reset();
    }, 1500);
  });

  // Sign Up Form Submission
  signUpForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const name = document.getElementById("signUpName").value.trim();
    const email = document.getElementById("signUpEmail").value.trim();
    const pass = document.getElementById("signUpPassword").value;
    const terms = document.getElementById("termsCheck").checked;
    const submitBtn = signUpForm.querySelector(".action-btn");

    if (!name) {
      triggerError(signUpForm, "Full Name is required");
      return;
    }

    if (!email || !email.includes("@")) {
      triggerError(signUpForm, "Please enter a valid work email");
      return;
    }

    if (pass.length < 8) {
      triggerError(signUpForm, "Password must be at least 8 characters");
      return;
    }

    if (!terms) {
      triggerError(signUpForm, "You must accept the Terms of Service");
      return;
    }

    submitBtn.classList.add("loading");

    setTimeout(() => {
      submitBtn.classList.remove("loading");
      showToast("Account created! Welcome to Nexus OS.", "success");
      signUpForm.reset();

      // Automatically slide curtain back to login view after successful sign up
      setTimeout(() => {
        btnToLogin.click();
      }, 1200);
    }, 1500);
  });

  function triggerError(formElement, message) {
    showToast(message, "error");
    formElement.classList.add("shake");
    setTimeout(() => {
      formElement.classList.remove("shake");
    }, 400);
  }
});